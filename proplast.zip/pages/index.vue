<template>
  <div>
    <Nav />
    <section class="landing">
      <div class="container">
        <!-- <img
          class="img1"
          src="../assets/img/6.jpg"
          alt=""
        />
        <img
          class="img2"
          src="../assets/img/7.jpg"
          alt=""
        />
        <img
          class="img3"
          src="../assets/img/8.jpg"
          alt=""
        />
        <img
          class="img4"
          src="../assets/img/9.jpg"
          alt=""
        /> -->
        <div class="middle">
          <img
            class="animate-reveal animate-first"
            src="../assets/img/middle.svg"
            alt=""
          />
          <h4 class="animate-reveal animate-second">PROPLAST</h4>
          <div class="flex-all animate-reveal animate-second">
            <hr />
            <p class="text-per">The Perfect Fit</p>
            <hr />
          </div>
          <p class="small-p animate-reveal animate-third">
            We are manufacturer, supplier, and trader company offering top-notch
            industrial pipes and fittings. Our staff is focused on providing
            exceptional services.
          </p>
        </div>
        <div class="collection-images"></div>
      </div>
    </section>
    <div class="wrapper">
      <section class="about-us row-max-grid">
        <div class="container">
          <div class="about-wrapper">
            <img src="../assets/img/2.jpg" alt="" />
            <div class="desc-about">
              <h2><b>PROPLAST PIPE AND FITTING MANUFACTURING</b></h2>
              <p>
                <br />
                is a private company established with a capital of 60 million
                birr in 2013 in E.C at Gondar to manufacture high quality uPVC
                Pipes, PPR Pipes,HDPE Pipes,uPVC FITTINGS, PPR FITTINGS
              </p>
            </div>
          </div>
        </div>
      </section>
      <section class="cta">
        <div class="container">
          <div class="wrapper">
            <p>
              We are manufacturer, supplier, and trader company offering
              top-notch industrial pipes and fittings. Our staff is focused on
              providing exceptional services.Proplast is a private company
              established with a capital of 60 million birr in 2013 in E.C at
              Gondar to manufacture high quality uPVC Pipes, PPR Pipes,HDPE
              Pipes,uPVC FITTINGS, PPR FITTINGS
            </p>
            <button class="btn btn-secondary">CONTACT US</button>
          </div>
        </div>
      </section>

      <section class="module product-list">
        <h3 class="section-title"><b>List of</b><span>Products</span></h3>
        <div class="content">
          <ul class="shows">
            <li></li>
          </ul>
        </div>
      </section>
      <section class="product-all-list">
        <div class="list">
          <div class="container">
            <div class="single-list">
              <img src="../assets/img/HDPEPIPES.png" alt="" />
              <h4>HDPE PIPES</h4>
              <p>
                are ageing concrete or steel mains pipes are frequently replaced
                , a flexible plastic pipe type utilized for fluid and gas
                transport.
              </p>
            </div>
            <div class="single-list">
              <img src="../assets/img/upvc.webp" alt="" />
              <h4>UPVC PIPES</h4>
              <p>
                are a durable option for all kinds of plumbing applications,Due
                to their excellent tensile and impact strength. 
              </p>
            </div>
            <div class="single-list">
              <img src="../assets/img/PPRFITTINGS.jpg" alt="" />
              <h4>PPR FITTINGS</h4>
              <p>
                are fittings in the development of cold and hot water systems.
              </p>
            </div>
            <div class="single-list">
              <img src="../assets/img/upvc.jpg" alt="" />
              <h4>UPVC FITTINGS</h4>
              <p>
                are an engineered plastic known as Unplasticized Polyvinyl
                Chloride. In the lack of plasticizers, which increase plastic's
                flexibility and reduce its brittleness, something is said to be
                "unplasticized."
              </p>
            </div>
            <div class="single-list">
              <img src="../assets/img/ppr.jpg" alt="" />
              <h4>PPR PIPES</h4>
              <p>
                (A polypropylene random co-polymer)is a type of plastic pipe
                constructed from this substance.
              </p>
            </div>
            <div class="single-list">
              <img src="../assets/img/condi.jpg" alt="" />
              <h4>Conduits</h4>
              <p>
                is a tube used in a building or other structure to protect and
                route electrical wiring. Metal, plastic, fiber, or burned clay
                can all be used to make electrical conduit.
              </p>
            </div>
          </div>
        </div>
      </section>
      <section class="videos">
        <h3 class="section-title"><span>New</span><b>Arrivals</b></h3>
        <div class="content">
          <a class="video-item">
            <p class="video-title">HDPE PIPES</p>
            <span class="video-icon"></span>
            <img src="../assets/img/HDPEPIPES2.jpg" alt="" />
          </a>
          <a class="video-item">
            <p class="video-title">PPR FITTINGS</p>
            <span class="video-icon"></span>
            <img src="../assets/img/PPRFITTINGS.jpg" alt="" />
          </a>

          <a class="video-item">
            <p class="video-title">PVC</p>
            <span class="video-icon"></span>
            <img src="../assets/img/proplast2.jpg" alt="" />
          </a>
        </div>
      </section>
      <div class="testimonials-section">
        <input
          type="radio"
          name="slider"
          title="slide1"
          checked="checked"
          class="slider__nav"
        />
        <input type="radio" name="slider" title="slide2" class="slider__nav" />
        <input type="radio" name="slider" title="slide3" class="slider__nav" />
        <input type="radio" name="slider" title="slide4" class="slider__nav" />
        <input type="radio" name="slider" title="slide5" class="slider__nav" />
        <div class="slider__inner">
          <div class="slider__contents">
            <quote>&rdquo;</quote>
            <p class="slider__txt">
              We love you guys. It's easy to order, we get shipments quick and
              my rep solves tough problems the right way. We get answers that
              work.
            </p>
            <h2 class="slider__caption">Rhonda | NylonCraft</h2>
          </div>
          <div class="slider__contents">
            <quote>&rdquo;</quote>
            <p class="slider__txt">
              You all bend over backwards to get it done. Inside sales and the
              Account Managers are great! It's your service...you all know that
              it's not just about taking orders it's about service.
            </p>
            <h2 class="slider__caption">Jared | Rexam</h2>
          </div>
          <div class="slider__contents">
            <quote>&rdquo;</quote>
            <p class="slider__txt">
              It's the long-term relationship we have with Proheat that keeps me
              calling you guys. I trust you, you're quick, and everybody I've
              ever spoken to there are all great people. That's exactly what
              Proheat does, and I couldn't be happier.
            </p>
            <h2 class="slider__caption">Chris | C&M Fine Pack</h2>
          </div>
          <div class="slider__contents">
            <quote>&rdquo;</quote>
            <p class="slider__txt">
              You answer my questions, always takes care of problems, and I
              never have a hassle.
            </p>
            <h2 class="slider__caption">Rex | LNP Engineering Plastics</h2>
          </div>
          <div class="slider__contents">
            <quote>&rdquo;</quote>
            <p class="slider__txt">
              Proheat's staff are all so friendly and everybody goes above and
              beyond. Everyone is courteous, everything is quick and you get us
              what we need.
            </p>
            <h2 class="slider__caption">Darlene | Russel Stover</h2>
          </div>
        </div>
      </div>
      <section class="module">
        <h3 class="section-title"><span>Contact </span><b>Us</b></h3>
        <div class="content"></div>
      </section>
      <Contactus />
      <section class="map follow">
        <div class="container">
          <h3 class="section-title"><span>Our</span><b>Location</b></h3>
          <p class="text center">
            If you want to register or contact us in person here is the link for
            our location.
          </p>
          <div class="separt1">
            <div class="container">
              <div class="box"></div>
            </div>
          </div>

          <div class="map-container">
            <div class="location">
              <div class="map-responsive">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d62299.41569535554!2d37.421428505145286!3d12.601125321440048!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x164328823d244edf%3A0x7826245358a8a65!2sGondar!5e0!3m2!1sen!2set!4v1665662658516!5m2!1sen!2set"
                  width="600"
                  height="450"
                  style="border: 0"
                  allowfullscreen=""
                  loading="lazy"
                  referrerpolicy="no-referrer-when-downgrade"
                ></iframe>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    <Footer />
  </div>
</template>

<script>
import Footer from "../components/Footer.vue";
import Contactus from "../components/Contactus.vue";
import Nav from "../components/Nav.vue";
export default {
  name: "IndexPage",
  mounted() {
    window.addEventListener("load", (event) => {
      const arrowNext = document.querySelector(".button-next"),
        arrowPrev = document.querySelector(".button-prev"),
        imageActive = document.querySelector(".active img"),
        imageNext = document.querySelector(".next img"),
        slideActive = document.querySelector(".active"),
        slideNext = document.querySelector(".next");

      const images = [
        {
          id: 0,
          image: "https://rafaelalucas.com/dailyui/3/assets/angele-03.jpg",
        },
        {
          id: 1,
          image: "https://rafaelalucas.com/dailyui/3/assets/angele-10.jpg",
        },
        {
          id: 2,
          image: "https://rafaelalucas.com/dailyui/3/assets/angele-11.jpg",
        },
        {
          id: 3,
          image: "https://rafaelalucas.com/dailyui/3/assets/angele-12.jpg",
        },
      ];

      arrowNext.addEventListener("click", nextPhoto);
      arrowPrev.addEventListener("click", prevPhoto);

      function nextPhoto() {
        const nextId = ~~imageNext.dataset.id + 1,
          nextPicture = images.find((element) => element.id == nextId),
          bullet = document.querySelectorAll(".bullet"),
          activeBullet = [...bullet].find(
            (element) => element.dataset.id == ~~imageNext.dataset.id
          );

        // Add Classes to Anime Photos

        slideNext.classList.add("anime-next-in");
        slideActive.classList.add("anime-in");

        // To Remove the Class that anime in
        setTimeout(function () {
          slideActive.classList.remove("anime-in");
          slideNext.classList.remove("anime-next-in");
        }, 960);

        // To Populate the Active and Next Slide

        imageActive.src = imageNext.src;
        imageActive.dataset.id = imageNext.dataset.id;

        if (imageActive.dataset.id == images.length - 1) {
          imageNext.src = images[0].image;
          imageNext.dataset.id = images[0].id;
        } else {
          imageNext.src = nextPicture.image;
          imageNext.dataset.id = nextPicture.id;
        }

        // To Add Active bullets
        bullet.forEach(function (el) {
          el.classList.remove("selected");
        });
        activeBullet.classList.add("selected");
      }

      function prevPhoto() {
        const prevId = ~~imageActive.dataset.id - 1,
          prevPicture = images.find((element) => element.id == prevId),
          bullet = document.querySelectorAll(".bullet");
        let activeBullet = [...bullet].find(
          (element) => element.dataset.id == prevId
        );

        // Add Classes to Anime Photos

        slideActive.classList.add("anime-out");
        slideNext.classList.add("anime-next-out");

        // To Remove the Class that anime in
        setTimeout(function () {
          slideActive.classList.remove("anime-out");
          slideNext.classList.remove("anime-next-out");
        }, 960);

        // To Populate the Active and Next Slide
        if (imageActive.dataset.id == 0) {
          imageNext.src = imageActive.src;
          imageNext.dataset.id = imageActive.dataset.id;
          imageActive.src = images[images.length - 1].image;
          imageActive.dataset.id = images[images.length - 1].id;
          activeBullet = [...bullet].find(
            (element) => element.dataset.id == imageActive.dataset.id
          );
        } else {
          imageNext.src = imageActive.src;
          imageNext.dataset.id = imageActive.dataset.id;
          imageActive.src = prevPicture.image;
          imageActive.dataset.id = prevPicture.id;
        }

        // To Add Active bullets
        bullet.forEach(function (el) {
          el.classList.remove("selected");
        });
        activeBullet.classList.add("selected");
      }

      // To Populate the first images on page load
      imageActive.src = images[0].image;
      imageActive.dataset.id = images[0].id;

      imageNext.src = images[1].image;
      imageNext.dataset.id = images[1].id;

      // Sticky menu

      window.onscroll = function () {
        if (window.pageYOffset >= 90) {
          iconMenu.classList.add("sticky");
        } else {
          iconMenu.classList.remove("sticky");
        }
      };
      // open menu

      const iconMenu = document.querySelector(".icon-menu"),
        menuOverlay = document.querySelector(".main-nav"),
        body = document.querySelector("body");

      iconMenu.addEventListener("click", openMenu);

      // Sticky menu

      window.onscroll = function () {
        if (window.pageYOffset >= 90) {
          iconMenu.classList.add("sticky");
        } else {
          iconMenu.classList.remove("sticky");
        }
      };

      function openMenu() {
        if (iconMenu.classList.contains("icon-open")) {
          menuOverlay.classList.add("menu-close");
          iconMenu.classList.remove("icon-open");
          body.classList.remove("no-scroll");
          iconMenu.classList.remove("sticky");

          setTimeout(function () {
            menuOverlay.classList.remove("menu-open");
          }, 800);
          setTimeout(function () {
            menuOverlay.classList.remove("menu-close");
          }, 900);
        } else {
          menuOverlay.classList.remove("menu-close");
          menuOverlay.classList.add("menu-open");
          iconMenu.classList.add("icon-open");
          body.classList.add("no-scroll");

          setTimeout(function () {
            iconMenu.classList.remove("sticky");
          }, 500);
        }
      }

      // open modal video

      const videoItem = document.querySelectorAll(".video-item"),
        modalVideo = document.querySelector(".modal-video"),
        iconCloseVideo = document.querySelector(".close-video"),
        videoFrame = document.querySelector(".video-code iframe"),
        videoOpen = document.querySelector(".video-open");

      videoItem.forEach(function (el) {
        el.addEventListener("click", openVideo);
      });

      iconCloseVideo.addEventListener("click", closeVideo);
      // body.addEventListener("click", closeVideo);

      function openVideo(e) {
        const videoSrc = e.currentTarget.dataset.video;

        body.classList.add("no-scroll");

        modalVideo.classList.add("video-open");

        videoFrame.src = videoSrc;
      }

      // ytLink.href = videoUrl;

      function closeVideo() {
        body.classList.remove("no-scroll");
        modalVideo.classList.remove("video-open");
        videoFrame.src = "";
      }
    });
  },
  components: { Footer, Contactus, Nav },
};
</script>
